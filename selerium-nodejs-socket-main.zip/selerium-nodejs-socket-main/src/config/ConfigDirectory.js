const path = require('path')

const ConfigDirectory = {
    publicDir: path.join(__dirname + '/../public'),
    templateDir: path.join(__dirname + '/../template')
}

module.exports = ConfigDirectory